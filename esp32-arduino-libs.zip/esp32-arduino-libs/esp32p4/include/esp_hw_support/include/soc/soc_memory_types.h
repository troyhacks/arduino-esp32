/*
 * SPDX-FileCopyrightText: 2010-2021 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#pragma once
#include "esp_memory_utils.h"
#warning "soc_memory_types.h is deprecated, please migrate to esp_memory_utils.h"
