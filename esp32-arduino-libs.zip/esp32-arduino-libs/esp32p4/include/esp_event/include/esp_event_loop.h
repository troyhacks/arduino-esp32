/*
 * SPDX-FileCopyrightText: 2024 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#pragma once

#warning "esp_event_loop.h is deprecated, please include esp_event.h instead"

#include "esp_event.h"
