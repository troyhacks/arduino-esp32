/*
 * SPDX-FileCopyrightText: 2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */

#warning "{target}/rom/miniz.h is deprecated, please use (#include "miniz.h") instead"
#include "../../../../miniz.h"
