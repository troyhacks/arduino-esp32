/*
 * SPDX-FileCopyrightText: 2020-2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */


#pragma once

#warning "esp_pm_config_esp32c3_t is deprecated, please include esp_pm.h and use esp_pm_config_t instead"

/* backward compatibility */
#include "esp_pm.h"
